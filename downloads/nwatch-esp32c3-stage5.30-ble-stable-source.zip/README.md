# NWatch ESP32-C3 Stage 5.30 — BLE Stable

Firmware cho ESP32-C3 Super Mini, OLED SH1106 1.3 inch I2C, DS3231 và ba nút.

## Thay đổi chính

- Dùng NimBLE-Arduino 2.4.0. NimBLE 2.5.1 đã gây mất cổng USB ngay sau khi BLE khởi tạo trên bo thử nghiệm; 2.3.2 không reset nhưng không bật được quảng bá BLE (`HCI 519`).
- BLE chỉ khởi tạo sau khi giao diện boot hoàn tất.
- Mục `CONNECT` có công tắc Bluetooth ON/OFF.
- Nhấn nút giữa trong màn hình Bluetooth để đổi ON/OFF; giữ nút giữa để quay lại.
- Trạng thái Bluetooth lưu bằng Preferences/NVS với khóa `ble`, nên vẫn được giữ sau khi tắt nguồn hoặc reset.
- Khi Bluetooth OFF, stack và radio BLE được dừng; lần khởi động tiếp theo không khởi tạo BLE.
- Khi Bluetooth ON, thiết bị quảng bá với tên `NWatch C3`, hỗ trợ ANCS và CTS cho iPhone.

## Chân kết nối

- SDA OLED + DS3231: GPIO 0
- SCL OLED + DS3231: GPIO 1
- Nút lên: GPIO 10
- Nút giữa: GPIO 20
- Nút xuống: GPIO 21
- OLED và DS3231: 3V3 + GND

## Cách dùng Bluetooth

1. Vào `MAIN MENU` → `CONNECT`.
2. Nhấn nút giữa để chuyển `BLUETOOTH: ON` hoặc `BLUETOOTH: OFF`.
3. Khi ON, mở Bluetooth trên iPhone và ghép đôi với `NWatch C3`.
4. Chấp nhận quyền chia sẻ thông báo khi iPhone hỏi. Đồng hồ sẽ đồng bộ giờ qua CTS và nhận thông báo qua ANCS.

Thiết bị mới mặc định Bluetooth ON. Nếu đã từng chọn OFF thì firmware nhớ trạng thái đó sau khi reset.

## ROM

- `nwatch-esp32c3-stage5.30-ble-stable.bin`: ROM đầy đủ, nạp tại địa chỉ `0x0`.
- `nwatch-esp32c3-stage5.30-ble-stable-app.bin`: chỉ firmware ứng dụng, nạp tại `0x10000` khi bo đã có bootloader và partition đúng.

Thông số nạp: ESP32-C3, DIO, 40 MHz, flash 4 MB, baud 115200.

## Kết quả kiểm tra

- Log khởi tạo đạt `PAIR NWatch C3`, xác nhận BLE đang quảng bá thật.
- Theo dõi cổng USB 150 giây sau khi BLE hoạt động: chỉ có trạng thái `PRESENT` ban đầu, không mất cổng và không bootloop.
- Serial Monitor được cấu hình DTR/RTS bằng 0. Trên USB native của ESP32-C3, riêng việc mở cổng monitor vẫn có thể tạo một lần `USB_UART_CHIP_RESET`; đây không phải bootloop.

## Build

Mở thư mục này bằng VS Code + PlatformIO và chạy `PlatformIO: Build`. File app sinh tại `.pio/build/esp32-c3-supermini/firmware.bin`.
